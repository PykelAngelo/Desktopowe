package com.example.kalkulator;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText numer1, numer2;
    TextView wynik;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        numer1 = findViewById(R.id.pierwsza);
        numer2 = findViewById(R.id.druga);
        wynik = findViewById(R.id.wynik);


        Button dodawanie = findViewById(R.id.dodawanie);
        Button odejmowanie = findViewById(R.id.odejmowanie);
        Button mnozenie = findViewById(R.id.mnozenie);
        Button dzielenie = findViewById(R.id.dzielenie);
        Button pierwiastek = findViewById(R.id.pierwiastek);
        Button potega = findViewById(R.id.potega);




        dodawanie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double result = Double.parseDouble(numer1.getText().toString()) + Double.parseDouble(numer2.getText().toString());
                wynik.setText("wynik: " + result);
            }
        });

        odejmowanie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double result = Double.parseDouble(numer1.getText().toString()) - Double.parseDouble(numer2.getText().toString());
                wynik.setText("wynik: " + result);
            }
        });

        mnozenie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(Double.parseDouble(numer1.getText().toString()) <= 0  || Double.parseDouble(numer2.getText().toString()) <= 0) {
                    wynik.setText("Nie można mnożyć przez 0");
                }else
                {
                    double result = Double.parseDouble(numer1.getText().toString()) * Double.parseDouble(numer2.getText().toString());
                    wynik.setText("wynik: " + result);
                }
            }
        });

        dzielenie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Double.parseDouble(numer1.getText().toString()) <= 0 || Double.parseDouble(numer2.getText().toString()) <= 0){
                    wynik.setText("Nie można dzielić przez 0");
                }else {
                    double result = Double.parseDouble(numer1.getText().toString()) / Double.parseDouble(numer2.getText().toString());
                    wynik.setText("wynik: " + result);
                }
            }
        });

        pierwiastek.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    double result = Math.pow(Double.parseDouble(numer1.getText().toString()), Double.parseDouble(numer2.getText().toString()));
                    wynik.setText("wynik: " + result);
            }
        });

        potega.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Double.parseDouble(numer1.getText().toString()) < 0 || Double.parseDouble(numer2.getText().toString()) < 0){
                    wynik.setText("nie można pierwiastkować liczb ujemnych");
                }else {
                    double result = Math.sqrt(Double.parseDouble(numer1.getText().toString()));
                    double result2 = Math.sqrt(Double.parseDouble(numer2.getText().toString()));
                    wynik.setText("wynik z pierwszej liczby: " + result + "\n" + "wynik z drugiej liczby: " + result2);
                }
            }
        });
    };
}

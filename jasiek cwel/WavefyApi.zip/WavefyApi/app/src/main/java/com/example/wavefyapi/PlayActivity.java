package com.example.wavefyapi;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PlayActivity extends AppCompatActivity {

    private TextView trackTitle;
    private TextView trackArtist;
    private ImageView trackImage;
    private MediaPlayer mediaPlayer;
    private ImageView backgroundImage;
    private ImageButton playButton;

    private int audioResId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);

        String title = getIntent().getStringExtra("track_title");
        String artist = getIntent().getStringExtra("track_artist");
        int imageResId = getIntent().getIntExtra("track_image_res_id", -1);
        audioResId = getIntent().getIntExtra("track_audio_res_id", -1);

        trackTitle = findViewById(R.id.trackTitle);
        trackArtist = findViewById(R.id.trackArtist);
        trackImage = findViewById(R.id.trackImage);
        playButton = findViewById(R.id.playButton);
        backgroundImage = findViewById(R.id.backgroundImage);

        trackTitle.setText(title);
        trackArtist.setText(artist);
        if (imageResId != -1) {
            trackImage.setImageResource(imageResId);
            backgroundImage.setImageResource(imageResId);
        }

        playButton.setOnClickListener(v -> {
            if (mediaPlayer == null && audioResId != -1) {
                mediaPlayer = MediaPlayer.create(this, audioResId);
            }

            if (mediaPlayer != null) {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.pause();
                    playButton.setImageResource(R.drawable.ic_play); // Pokazujemy ikonę „Play”
                } else {
                    mediaPlayer.start();
                    playButton.setImageResource(R.drawable.ic_pause); // Pokazujemy ikonę „Pause”
                }
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}

package com.example.wavefyapi;

import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AuthActivity extends AppCompatActivity {

    private static final String TAG = "AuthActivity"; // Dodanie tagu do logów

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Uri uri = getIntent().getData();

        if (uri != null) {
            Log.d(TAG, "Otrzymano URI: " + uri.toString());
        }

        if (uri != null && uri.toString().startsWith("wavefy://callback")) {
            String code = uri.getQueryParameter("code");
            if (code != null) {
                Log.d(TAG, "Otrzymano kod autoryzacyjny: " + code);
                new SpotifyAuthCodeExchange(this).exchangeAuthorizationCode(code);
            } else {
                handleError("Brak kodu autoryzacyjnego w URI");
            }
        } else {
            handleError("Nieprawidłowy URI powrotu: " + (uri != null ? uri.toString() : "null"));
        }
    }

    private void handleError(String errorMessage) {
        Log.e(TAG, errorMessage);
        Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show();
        finish();
    }
}
package com.example.wavefyapi;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;
import android.util.Log;
import android.widget.Toast;
import android.content.Intent;
import okhttp3.*;

import org.json.JSONObject;

import java.io.IOException;

public class SpotifyAuthCodeExchange {
    private static final String CLIENT_ID = "d61452f55d9c409ab06f3a92bce18685";
    private static final String CLIENT_SECRET = "725885c61aaa49c0a70dddf8dd2f9505";
    private static final String REDIRECT_URI = "wavefy://callback";
    private static final String TOKEN_URL = "https://accounts.spotify.com/api/token";

    private final OkHttpClient client = new OkHttpClient();
    private final SharedPreferences sharedPreferences;
    private final Context context;

    public SpotifyAuthCodeExchange(Context context) {
        this.context = context;
        this.sharedPreferences = context.getSharedPreferences("SpotifyPrefs", Context.MODE_PRIVATE);
    }

    public void exchangeAuthorizationCode(String code) {
        String credentials = CLIENT_ID + ":" + CLIENT_SECRET;
        String encodedCredentials = Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);

        RequestBody requestBody = new FormBody.Builder()
                .add("grant_type", "authorization_code")
                .add("code", code)
                .add("redirect_uri", REDIRECT_URI)
                .build();

        Request request = new Request.Builder()
                .url(TOKEN_URL)
                .addHeader("Authorization", "Basic " + encodedCredentials)
                .post(requestBody)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e("SpotifyAuth", "Błąd wymiany kodu", e);
                showErrorMessage("Błąd połączenia z serwerem.");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    Log.e("SpotifyAuth", "Nieudana odpowiedź: " + response.code() + " - " + response.message());
                    showErrorMessage("Błąd podczas pobierania tokenów.");
                    return;
                }

                String responseBody = response.body().string();
                Log.d("SpotifyAuth", "Response Body: " + responseBody); // Logowanie pełnej odpowiedzi

                try {
                    JSONObject json = new JSONObject(responseBody);
                    String accessToken = json.getString("access_token");
                    String refreshToken = json.getString("refresh_token");
                    long expiresIn = json.getLong("expires_in");

                    Log.d("SpotifyAuth", "Access Token: " + accessToken);
                    Log.d("SpotifyAuth", "Refresh Token: " + refreshToken);

                    sharedPreferences.edit()
                            .putString("access_token", accessToken)
                            .putString("refresh_token", refreshToken)
                            .putLong("token_expiry_time", System.currentTimeMillis() + expiresIn * 1000)
                            .apply();

                    Log.d("SpotifyAuth", "Zapisano tokeny!");
                    showSuccessMessage("Tokeny zostały zapisane!");

                    // Przejście do MainActivity po zakończeniu
                    Intent intent = new Intent(context, MainActivity.class);
                    context.startActivity(intent);
                } catch (Exception e) {
                    Log.e("SpotifyAuth", "Błąd parsowania odpowiedzi", e);
                    showErrorMessage("Błąd parsowania danych.");
                }
            }
        });
    }

    private void showErrorMessage(String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }

    private void showSuccessMessage(String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }
}
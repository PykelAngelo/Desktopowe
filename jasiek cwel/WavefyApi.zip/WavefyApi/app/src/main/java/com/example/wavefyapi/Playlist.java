package com.example.wavefyapi;

import java.util.List;

public class Playlist {
    private String name;
    private List<String> songs;

    public Playlist(String name, List<String> songs) {
        this.name = name;
        this.songs = songs;
    }

    public String getName() {
        return name;
    }

    public List<String> getSongs() {
        return songs;
    }
}

package com.example.wavefyapi;

public class SearchResult {
    private String title;
    private String artist;

    public SearchResult(String title, String artist) {
        this.title = title;
        this.artist = artist;
    }

    public String getTitle() {
        return title;
    }

    public String getArtist() {
        return artist;
    }
}
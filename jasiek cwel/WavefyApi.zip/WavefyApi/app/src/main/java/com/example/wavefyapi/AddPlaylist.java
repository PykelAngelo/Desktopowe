package com.example.wavefyapi;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class AddPlaylist extends AppCompatActivity {

    private EditText nazwaPlaylistyEditText;
    private EditText song1, song2, song3, song4, song5;
    private Button addPlaylistButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playlist);

        nazwaPlaylistyEditText = findViewById(R.id.nazwaPlaylisty);
        song1 = findViewById(R.id.song1);
        song2 = findViewById(R.id.song2);
        song3 = findViewById(R.id.song3);
        song4 = findViewById(R.id.song4);
        song5 = findViewById(R.id.song5);
        addPlaylistButton = findViewById(R.id.addTrackToPlaylist);

        addPlaylistButton.setOnClickListener(v -> {
            String nazwa = nazwaPlaylistyEditText.getText().toString().trim();

            if (nazwa.isEmpty()) {
                Toast.makeText(this, "Podaj nazwę playlisty!", Toast.LENGTH_SHORT).show();
                return;
            }

            ArrayList<String> songs = new ArrayList<>();
            if (!song1.getText().toString().trim().isEmpty()) songs.add(song1.getText().toString().trim());
            if (!song2.getText().toString().trim().isEmpty()) songs.add(song2.getText().toString().trim());
            if (!song3.getText().toString().trim().isEmpty()) songs.add(song3.getText().toString().trim());
            if (!song4.getText().toString().trim().isEmpty()) songs.add(song4.getText().toString().trim());
            if (!song5.getText().toString().trim().isEmpty()) songs.add(song5.getText().toString().trim());

            Intent resultIntent = new Intent();
            resultIntent.putExtra("playlist_name", nazwa);
            resultIntent.putStringArrayListExtra("playlist_songs", songs);
            setResult(RESULT_OK, resultIntent);
            finish();
        });
    }
}

package com.example.wavefyapi;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import org.json.JSONObject;

import java.io.IOException;

public class SpotifyApiHelper {

    public interface UserProfileCallback {
        void onProfileLoaded(String displayName);
        void onError(String error);
    }

    public static void getUserProfile(Context context, final UserProfileCallback callback) {
        SharedPreferences prefs = context.getSharedPreferences("SpotifyPrefs", Context.MODE_PRIVATE);
        String accessToken = prefs.getString("access_token", null);
        Log.d("SpotifyApiHelper", "Access Token: " + accessToken); // Dodaj logowanie
        if (accessToken == null) {
            callback.onError("Brak dostępu do tokenu");
            return;
        }

        try {
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url("https://api.spotify.com/v1/me")
                    .header("Authorization", "Bearer " + accessToken)
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(okhttp3.Call call, IOException e) {
                    Log.e("SpotifyApiHelper", "Error: " + e.getMessage(), e);
                    callback.onError("Błąd połączenia z API");
                }

                @Override
                public void onResponse(okhttp3.Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        String responseBody = response.body().string();
                        Log.d("SpotifyApiHelper", "API Response: " + responseBody);

                        try {
                            JSONObject jsonObject = new JSONObject(responseBody);
                            String displayName = jsonObject.getString("display_name");
                            callback.onProfileLoaded(displayName);  // Wywołaj callback z nazwą użytkownika
                        } catch (Exception e) {
                            Log.e("SpotifyApiHelper", "Błąd parsowania odpowiedzi", e);
                            callback.onError("Błąd parsowania danych");
                        }
                    } else {
                        Log.e("SpotifyApiHelper", "API Error: " + response.code() + " - " + response.message());
                        callback.onError("Błąd API: " + response.message());
                    }
                }
            });
        } catch (Exception e) {
            Log.e("SpotifyApiHelper", "Error: " + e.getMessage(), e);
            callback.onError("Błąd: " + e.getMessage());
        }
    }
}
package com.example.wavefyapi;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends AppCompatActivity {

    private EditText editTextSearch;
    private Button searchButton;
    private RecyclerView recyclerViewSearchResults;
    private SearchResultAdapter adapter;
    private List<SearchResult> searchResults;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        editTextSearch = findViewById(R.id.editTextSearch);
        searchButton = findViewById(R.id.searchButton);
        recyclerViewSearchResults = findViewById(R.id.recyclerViewSearchResults);

        searchResults = new ArrayList<>();
        adapter = new SearchResultAdapter(searchResults);
        recyclerViewSearchResults.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewSearchResults.setAdapter(adapter);

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String query = editTextSearch.getText().toString().trim();
                performSearch(query);
            }
        });
    }

    private void performSearch(String query) {
        //wyniki tutaj na razie są symulowane, bez użycia api spotify do wyszukiwania utworów, api spotify używane jest do zalogowania się
        searchResults.clear();

        if (!query.isEmpty()) {
            searchResults.add(new SearchResult("Blinding Lights", "The Weeknd"));
            searchResults.add(new SearchResult("Save Your Tears", "The Weeknd"));
            searchResults.add(new SearchResult("Starboy", "The Weeknd"));
        }

        adapter.notifyDataSetChanged();
    }
}
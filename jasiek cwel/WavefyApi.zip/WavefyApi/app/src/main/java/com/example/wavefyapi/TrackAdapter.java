package com.example.wavefyapi;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;

import androidx.recyclerview.widget.RecyclerView;


import java.util.List;

public class TrackAdapter extends RecyclerView.Adapter<TrackAdapter.TrackViewHolder> {

    private Context context;
    private List<Track> trackList;
    private OnTrackClickListener onTrackClickListener;

    public TrackAdapter(Context context, List<Track> trackList) {
        this.context = context;
        this.trackList = trackList;
    }

    public void setOnTrackClickListener(OnTrackClickListener listener) {
        this.onTrackClickListener = listener;
    }

    @Override
    public TrackViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.track, parent, false);
        return new TrackViewHolder(view);
    }

    @Override
    public void onBindViewHolder(TrackViewHolder holder, int position) {
        Track track = trackList.get(position);
        holder.trackTitle.setText(track.getTitle());
        holder.trackArtist.setText(track.getArtist());
        holder.trackImage.setImageResource(track.getImageResource());

        holder.itemView.setOnClickListener(v -> {
            if (onTrackClickListener != null) {
                onTrackClickListener.onTrackClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return trackList.size();
    }

    public interface OnTrackClickListener {
        void onTrackClick(int position);
    }

    public class TrackViewHolder extends RecyclerView.ViewHolder {

        private TextView trackTitle, trackArtist;
        private ImageView trackImage;

        public TrackViewHolder(View itemView) {
            super(itemView);
            trackTitle = itemView.findViewById(R.id.trackTitle);
            trackArtist = itemView.findViewById(R.id.trackArtist);
            trackImage = itemView.findViewById(R.id.trackImage);
        }
    }
}
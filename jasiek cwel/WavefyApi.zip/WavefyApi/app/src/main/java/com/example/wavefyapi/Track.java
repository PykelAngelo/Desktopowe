package com.example.wavefyapi;

public class Track {
    private String title;
    private String artist;
    private int imageResource;
    private int audioResource;

    public Track(String title, String artist, int imageResource, int audioResource) {
        this.title = title;
        this.artist = artist;
        this.imageResource = imageResource;
        this.audioResource = audioResource;
    }

    public String getTitle() {
        return title;
    }

    public String getArtist() {
        return artist;
    }

    public int getImageResource() {
        return imageResource;
    }

    public int getAudioResource() {
        return audioResource;
    }
}
package com.example.wavefyapi;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PlaylistAdapter extends RecyclerView.Adapter<PlaylistAdapter.PlaylistViewHolder> {

    private Context context;
    private List<Playlist> playlistList;

    public PlaylistAdapter(Context context, List<Playlist> playlistList) {
        this.context = context;
        this.playlistList = playlistList;
    }

    @NonNull
    @Override
    public PlaylistViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.playlist_item, parent, false);
        return new PlaylistViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PlaylistViewHolder holder, int position) {
        Playlist playlist = playlistList.get(position);
        holder.playlistName.setText(playlist.getName());

        List<String> songs = playlist.getSongs();

        holder.song1.setText(songs.size() > 0 ? "• " + songs.get(0) : "");
        holder.song2.setText(songs.size() > 1 ? "• " + songs.get(1) : "");
        holder.song3.setText(songs.size() > 2 ? "• " + songs.get(2) : "");
    }

    @Override
    public int getItemCount() {
        return playlistList != null ? playlistList.size() : 0;
    }

    public static class PlaylistViewHolder extends RecyclerView.ViewHolder {
        TextView playlistName, song1, song2, song3;

        public PlaylistViewHolder(@NonNull View itemView) {
            super(itemView);
            playlistName = itemView.findViewById(R.id.playlistName);
            song1 = itemView.findViewById(R.id.song1);
            song2 = itemView.findViewById(R.id.song2);
            song3 = itemView.findViewById(R.id.song3);
        }
    }
}

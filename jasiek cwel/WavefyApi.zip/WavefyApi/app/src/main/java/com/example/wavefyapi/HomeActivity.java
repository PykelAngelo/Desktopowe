package com.example.wavefyapi;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    private Button searchButton;
    private Button addPlaylistButton;
    private RecyclerView recyclerViewTracks;
    private TrackAdapter trackAdapter;
    private List<Track> trackList;

    private RecyclerView recyclerViewPlaylists;
    private PlaylistAdapter playlistAdapter;
    private List<Playlist> playlistList;

    private MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        searchButton = findViewById(R.id.searchButton);
        addPlaylistButton = findViewById(R.id.addPlaylistButton);
        recyclerViewTracks = findViewById(R.id.recyclerViewPopularTracks);
        recyclerViewTracks.setLayoutManager(new LinearLayoutManager(this));

        trackList = new ArrayList<>();
        trackList.add(new Track("The Hills", "The Weeknd", R.drawable.thehills, R.raw.thehills));
        trackList.add(new Track("Sicko Mode", "Travis Scott", R.drawable.sickomode, R.raw.sickomode));
        trackList.add(new Track("7 Rings", "Ariana Grande", R.drawable.rings, R.raw.rings));
        trackList.add(new Track("Blinding Lights", "The Weeknd", R.drawable.blindinglights, R.raw.blindinglights));

        trackAdapter = new TrackAdapter(this, trackList);
        recyclerViewTracks.setAdapter(trackAdapter);

        trackAdapter.setOnTrackClickListener(position -> {
            Track selectedTrack = trackList.get(position);

            Intent intent = new Intent(HomeActivity.this, PlayActivity.class);
            intent.putExtra("track_title", selectedTrack.getTitle());
            intent.putExtra("track_artist", selectedTrack.getArtist());
            intent.putExtra("track_image_res_id", selectedTrack.getImageResource());
            intent.putExtra("track_audio_res_id", selectedTrack.getAudioResource());
            startActivity(intent);
        });

        recyclerViewPlaylists = findViewById(R.id.recyclerViewPlaylists);
        recyclerViewPlaylists.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));

        playlistList = new ArrayList<>();

        List<String> ulubione = new ArrayList<>();
        ulubione.add("The Hills");
        ulubione.add("Blinding Lights");
        ulubione.add("Save Your Tears");

        List<String> chillout = new ArrayList<>();
        chillout.add("Daydreamin'");
        chillout.add("Sunflower");
        chillout.add("Lovely");

        List<String> impreza = new ArrayList<>();
        impreza.add("Sicko Mode");
        impreza.add("Yeah!");
        impreza.add("One Dance");

        playlistList.add(new Playlist("Moje ulubione", ulubione));
        playlistList.add(new Playlist("Chillout", chillout));
        playlistList.add(new Playlist("Na imprezę", impreza));

        playlistAdapter = new PlaylistAdapter(this, playlistList);
        recyclerViewPlaylists.setAdapter(playlistAdapter);

        Toast.makeText(this, "Liczba playlist: " + playlistList.size(), Toast.LENGTH_SHORT).show();

        addPlaylistButton.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, AddPlaylist.class);
            startActivityForResult(intent, 1);
        });

        searchButton.setOnClickListener(v -> {
            Toast.makeText(this, "Przechodzisz do wyszukiwania", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(HomeActivity.this, SearchActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            String newPlaylistName = data.getStringExtra("playlist_name");
            ArrayList<String> songs = data.getStringArrayListExtra("playlist_songs");

            if (newPlaylistName != null && !newPlaylistName.isEmpty()) {
                Playlist newPlaylist = new Playlist(newPlaylistName, songs != null ? songs : new ArrayList<>());
                playlistList.add(newPlaylist);
                playlistAdapter.notifyItemInserted(playlistList.size() - 1);
                Toast.makeText(this, "Dodano playlistę: " + newPlaylistName, Toast.LENGTH_SHORT).show();
            }
        }
    }


    @Override
    protected void onStop() {
        super.onStop();
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}

package com.example.wavefyapi;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private final String clientId = "d61452f55d9c409ab06f3a92bce18685";
    private final String redirectUri = "wavefy://callback";
    private final String responseType = "code";
    private final String scopes = "user-read-private user-read-email playlist-modify-public playlist-modify-private";

    private SpotifyTokenManager tokenManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tokenManager = new SpotifyTokenManager(this);

        // Sprawdzamy, czy mamy zapisany token
        if (tokenManager.isAccessTokenExpired()) {
            tokenManager.refreshAccessToken();
            Toast.makeText(this, "Token został odświeżony", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Token jest nadal ważny", Toast.LENGTH_SHORT).show();
            goToHomeActivity();
        }

        // Obsługa kliknięcia przycisku logowania
        Button loginButton = findViewById(R.id.login_button);
        loginButton.setOnClickListener(v -> StartSpotifyLogin());
    }

    // Metoda do rozpoczęcia logowania przez Spotify
    private void StartSpotifyLogin() {
        String authUrl = "https://accounts.spotify.com/authorize"
                + "?client_id=" + clientId
                + "&response_type=" + responseType
                + "&redirect_uri=" + Uri.encode(redirectUri)
                + "&scope=" + Uri.encode(scopes);

        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(authUrl));
        startActivity(browserIntent);
    }

    private void goToHomeActivity() {
        Intent homeIntent = new Intent(this, HomeActivity.class);
        startActivity(homeIntent);
    }
}
package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        EditText a = findViewById(R.id.a);
        EditText b = findViewById(R.id.ba);
        TextView w = findViewById(R.id.wyswietl);
        CheckBox checkBoxm2 = findViewById(R.id.m2);
        CheckBox checkBoxkm2 = findViewById(R.id.km2);
        CheckBox checkBoxhektar = findViewById(R.id.hektar);
        findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String war_a = a.getText().toString();
                String war_b = b.getText().toString();
                Double wynik = Double.parseDouble(war_a)*Double.parseDouble(war_b);
                String jednostka = "m²";
                if (checkBoxkm2.isChecked()){
                    wynik /= 1_000_000;
                    jednostka = "km²";
                } else if (checkBoxhektar.isChecked()) {
                    wynik /= 1_000;
                    jednostka = "ha";
                }
                w.setText("Pole: "+ wynik+" "+jednostka);

            }

        });
        View.OnClickListener checkBoxListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CheckBox clickedCheckBox = (CheckBox) v;
                checkBoxm2.setChecked(false);
                checkBoxkm2.setChecked(false);
                checkBoxhektar.setChecked(false);
                clickedCheckBox.setChecked(true);
            }
        };
        checkBoxm2.setOnClickListener(checkBoxListener);
        checkBoxkm2.setOnClickListener(checkBoxListener);
        checkBoxhektar.setOnClickListener(checkBoxListener);


    }
}
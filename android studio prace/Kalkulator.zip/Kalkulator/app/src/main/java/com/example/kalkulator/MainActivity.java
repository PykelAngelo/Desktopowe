package com.example.kalkulator;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    double x1 = 0, x2 = 0;
    int kodDzialania = 0;
    boolean trybPisania = true,
            pierwszeDzielanie = true;


    Button p1, p2, p3, p4, p5, p6, p7, p8, p9, p0, kasuj, wstecz, rowne, przecinek, zmianaZnaku, procent,
            pierwiastek, kwadrat, odwrotnosc, razy, podzielic, minus, plus;
    TextView wyswietlacz;
    boolean trybPisanie = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        odnajdzkontrolki();

        dodajsluchaczezdarzen();
        View.OnClickListener sluchaczZdarzen;
    }

    private void odnajdzkontrolki() {
        p1 = findViewById(R.id.one);
        p2 = findViewById(R.id.two);
        p3 = findViewById(R.id.three);
        p4 = findViewById(R.id.four);
        p5 = findViewById(R.id.five);
        p6 = findViewById(R.id.six);
        p7 = findViewById(R.id.seven);
        p8 = findViewById(R.id.eight);
        p9 = findViewById(R.id.nine);
        p0 = findViewById(R.id.zero);
        kasuj = findViewById(R.id.kasuj);
        wstecz = findViewById(R.id.back);


        przecinek = findViewById(R.id.coma);
        zmianaZnaku = findViewById(R.id.p_and_m);
        procent = findViewById(R.id.procent);
        pierwiastek = findViewById(R.id.sqrt);
        kwadrat = findViewById(R.id.sqr);
        odwrotnosc = findViewById(R.id.one_x);
        razy = findViewById(R.id.multi);
        podzielic = findViewById(R.id.devide);
        minus = findViewById(R.id.minus);
        plus = findViewById(R.id.plus);
        wyswietlacz = findViewById(R.id.wyswietlacz);
        rowne = findViewById(R.id.sum);
        wstecz = findViewById(R.id.back);
    }



    private void dodajsluchaczezdarzen() {
        View.OnClickListener sluchaczZdarzen = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int buttonId = v.getId();

                if (buttonId == R.id.one || buttonId == R.id.two || buttonId == R.id.three || buttonId == R.id.four ||
                        buttonId == R.id.five || buttonId == R.id.six || buttonId == R.id.seven || buttonId == R.id.eight ||
                        buttonId == R.id.nine || buttonId == R.id.zero) {
                    dodajCyfre(((Button) v).getText().toString());
                } else if (buttonId == R.id.kasuj) {
                    kasuj();
                } else if (buttonId == R.id.plus) {
                    dzialanie(1); // Addition
                } else if (buttonId == R.id.minus) {
                    dzialanie(2); // Subtraction
                } else if (buttonId == R.id.multi) {
                    dzialanie(3); // Multiplication
                } else if (buttonId == R.id.devide) {
                    dzialanie(4); // Division
                } else if (buttonId == R.id.p_and_m) {
                    zmienZnak();
                } else if (buttonId == R.id.coma) {
                    wstawPrzecinek();
                } else if (buttonId == R.id.procent) {
                    funkcja(1); // Percentage
                } else if (buttonId == R.id.sqrt) {
                    funkcja(2); // Square root
                } else if (buttonId == R.id.sqr) {
                    funkcja(3); // Square
                } else if (buttonId == R.id.one_x) {
                    funkcja(4); // Inverse
                } else if (buttonId == R.id.sum) {
                    dzialanie(0); // Equals
                } else if (buttonId == R.id.back) {
                    cofnij();
                }
            }
        };

        // Attaching the listener to all the buttons
        p1.setOnClickListener(sluchaczZdarzen);
        p2.setOnClickListener(sluchaczZdarzen);
        p3.setOnClickListener(sluchaczZdarzen);
        p4.setOnClickListener(sluchaczZdarzen);
        p5.setOnClickListener(sluchaczZdarzen);
        p6.setOnClickListener(sluchaczZdarzen);
        p7.setOnClickListener(sluchaczZdarzen);
        p8.setOnClickListener(sluchaczZdarzen);
        p9.setOnClickListener(sluchaczZdarzen);
        p0.setOnClickListener(sluchaczZdarzen);
        kasuj.setOnClickListener(sluchaczZdarzen);
        plus.setOnClickListener(sluchaczZdarzen);
        minus.setOnClickListener(sluchaczZdarzen);
        razy.setOnClickListener(sluchaczZdarzen);
        podzielic.setOnClickListener(sluchaczZdarzen);
        rowne.setOnClickListener(sluchaczZdarzen);
        wstecz.setOnClickListener(sluchaczZdarzen);
        zmianaZnaku.setOnClickListener(sluchaczZdarzen);
        przecinek.setOnClickListener(sluchaczZdarzen);
        procent.setOnClickListener(sluchaczZdarzen);
        kwadrat.setOnClickListener(sluchaczZdarzen);
        pierwiastek.setOnClickListener(sluchaczZdarzen);
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE)
            odwrotnosc.setOnClickListener(sluchaczZdarzen);
    }

    private void dodajCyfre(String s) {
        if (trybPisania) {
            String temp = wyswietlacz.getText().toString();
            if (temp.equals("0")) temp = "";
            wyswietlacz.setText(temp + s);
        } else {
            wyswietlacz.setText(s);
            trybPisania = true;
        }

    }

    private void cofnij() {
        String s = wyswietlacz.getText().toString();
        if (s.length() > 1) {
            s = s.substring(0, s.length() - 1);
        } else s = "0";
        wyswietlacz.setText(s);
    }

    private void dzialanie(int kodPrzycisku) {
        double wynik = 0;
        if (pierwszeDzielanie) {
            // Pierwsza liczba
            x1 = Double.parseDouble(wyswietlacz.getText().toString());
            pierwszeDzielanie = false;
        } else {
            // Druga liczba
            x2 = Double.parseDouble(wyswietlacz.getText().toString());
            switch (kodDzialania) {
                case 1: // Dodawanie
                    wynik = x1 + x2;
                    break;
                case 2: // Odejmowanie
                    wynik = x1 - x2;
                    break;
                case 3: // Mnożenie
                    wynik = x1 * x2;
                    break;
                case 4: // Dzielenie
                    if (x2 != 0) {
                        wynik = x1 / x2;
                    } else {
                        wyswietlacz.setText("Error");
                        return;
                    }
                    break;
            }
            // Zaktualizowanie x1 na wynik
            x1 = wynik;
            wyswietlacz.setText(String.valueOf(wynik));
        }
        // Ustawienie operacji
        kodDzialania = kodPrzycisku;

        // Jeśli kodDzialania to 0, resetujemy operację (dla "=")
        if (kodPrzycisku == 0) {
            pierwszeDzielanie = true;
        }

        // Zapobiega nadpisaniu tekstu przez kolejne wprowadzenie liczby
        trybPisania = false;
    }
    private void wyswietl(double w) {
        w = Math.round(w * 1000000) / 1000000.0;
        String s = String.valueOf(w);
        if (s.substring(s.length() - 2).equals(".")) s = s.substring(0, s.length() - 2);
        wyswietlacz.setText(s);
    }

    private void funkcja(int kodPrzycisku) {
        double wynik = 0;
        Double x = Double.parseDouble(wyswietlacz.getText().toString());
        switch (kodPrzycisku) {
            case 1:
                wynik = x * 100 ;
                break;
            case 2:
                wynik = Math.sqrt(x);
                break;
            case 3:
                wynik = x * x;
                break;
            case 4:
                wynik = 1 / x;
                break;
        }

        wyswietl(wynik);
        trybPisania = false;
    }

    private void zmienZnak() {
        String s = wyswietlacz.getText().toString();
        double w = Double.valueOf(s);
        wyswietl(-w);
    }

    private void kasuj() {
        wyswietlacz.setText("0");
        pierwszeDzielanie = true;
        kodDzialania = 0;
        trybPisania = true;
    }

    private void wstawPrzecinek() {
        if (trybPisania) {
            String s = wyswietlacz.getText().toString();
            if (s.indexOf('.') < 0) {
                s+= ".";
                wyswietlacz.setText(s);
            }
            else {
                wyswietlacz.setText(".");
                trybPisania = true;
            }
        }
    }
}
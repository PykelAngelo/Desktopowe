package com.example.dziennik_zywnosci;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {


    int CEL_WODA = 2000;
    int AktualnaWoda = 0;
    int CEL_KALORIE;
    int CEL_BIALKO;
    int CEL_TLUSZCZ;
    int CEL_WEGLE;

    private TextView tvPodsumowanie;
    private LinearLayout layoutLista;
    private TextView tvWoda;
    private TextView tvSen;



    @Override
    protected void onResume() {
        super.onResume();


        CEL_KALORIE = KalorieObliczenia.CEL_KALORIE;
        CEL_BIALKO = KalorieObliczenia.CEL_BIALKO;
        CEL_TLUSZCZ = KalorieObliczenia.CEL_TLUSZCZ;
        CEL_WEGLE = KalorieObliczenia.CEL_WEGLE;

        odswiezWidok();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvPodsumowanie = findViewById(R.id.tvSummary);
        layoutLista = findViewById(R.id.mealListLayout);
        tvSen = findViewById(R.id.tvSen);
        tvWoda = findViewById(R.id.tvWoda);

        Button btnDodaj = findViewById(R.id.btnAddMeal);
        btnDodaj.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DodajPosilekActivity.class);
            startActivity(intent);
        });

        Button btnWyczysc = findViewById(R.id.btnWyczysc);
        btnWyczysc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MagazynDanych.listaPosilkow.clear();
                AktualnaWoda = 0;
                MagazynDanych.aktualnySen = 0;
                odswiezWidok();
            }
        });

        tvWoda = findViewById(R.id.tvWoda);

        Button btnUstawienia = findViewById(R.id.btnUstawienia);
        btnUstawienia.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, UstawieniaActivity.class);
            startActivity(intent);
        });

        Button btnDodajWode = findViewById(R.id.btnDodajWode);
        btnDodajWode.setOnClickListener(v -> {
            AktualnaWoda += 250; // dodajemy 250 ml
            if (AktualnaWoda > CEL_WODA) AktualnaWoda = CEL_WODA; // max 1000 ml

            odswiezWidok();
        });

        odswiezWidok();

        tvSen.setText("Sen: " + MagazynDanych.przebytySen + " h");
        tvSen = findViewById(R.id.tvSen);

        Button btnSen = findViewById(R.id.btnSen);
        btnSen.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SenActivity.class);
            startActivity(intent);
        });


    }

    private void odswiezWidok() {
        int sumaKalorie = 0, sumaBialko = 0, sumaTluszcz = 0, sumaWegle = 0;
        layoutLista.removeAllViews();

        for (Posilek p : MagazynDanych.listaPosilkow) {
            sumaKalorie += p.getKalorie();
            sumaBialko += p.getBialko();
            sumaTluszcz += p.getTluszcz();
            sumaWegle += p.getWeglowodany();

            TextView posilekView = new TextView(this);
            posilekView.setText("- " + p.getNazwa() + " | " + p.getKalorie() + " kcal, B: " + p.getBialko() + "g, T: " + p.getTluszcz() + "g, W: " + p.getWeglowodany() + "g");
            layoutLista.addView(posilekView);
        }

        String podsumowanie = "Dzisiejsze spożycie:\n"
                + "Kalorie: " + sumaKalorie + " / " + CEL_KALORIE + " kcal\n"
                + "Białko: " + sumaBialko + " / " + CEL_BIALKO + " g\n"
                + "Tłuszcz: " + sumaTluszcz + " / " + CEL_TLUSZCZ + " g\n"
                + "Węglowodany: " + sumaWegle + " / " + CEL_WEGLE + " g";

        tvPodsumowanie.setText(podsumowanie);

        tvWoda.setText("Woda: " + AktualnaWoda + " ml / " + CEL_WODA + " ml");

        TextView tvSen = findViewById(R.id.tvSen); // musi istnieć w layout
        tvSen.setText("Sen: " + MagazynDanych.aktualnySen + " godz.");




    }
}

package com.example.dziennik_zywnosci;

import java.util.ArrayList;

public class MagazynDanych {
    public static ArrayList<Posilek> listaPosilkow = new ArrayList<>();
    public static int przebytySen = 0;
    public static int aktualnySen = 0;
}


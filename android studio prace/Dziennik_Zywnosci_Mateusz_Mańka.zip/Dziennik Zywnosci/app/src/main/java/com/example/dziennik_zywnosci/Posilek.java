package com.example.dziennik_zywnosci;

public class Posilek {
    private String nazwa;
    private int kalorie;
    private int bialko;
    private int tluszcz;
    private int weglowodany;

    public Posilek(String nazwa, int kalorie, int bialko, int tluszcz, int weglowodany) {
        this.nazwa = nazwa;
        this.kalorie = kalorie;
        this.bialko = bialko;
        this.tluszcz = tluszcz;
        this.weglowodany = weglowodany;
    }

    public String getNazwa() {
        return nazwa;
    }

    public int getKalorie() {
        return kalorie;
    }

    public int getBialko() {
        return bialko;
    }

    public int getTluszcz() {
        return tluszcz;
    }

    public int getWeglowodany() {
        return weglowodany;
    }
}

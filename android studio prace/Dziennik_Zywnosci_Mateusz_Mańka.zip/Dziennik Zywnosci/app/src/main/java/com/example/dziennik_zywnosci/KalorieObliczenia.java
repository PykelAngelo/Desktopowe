package com.example.dziennik_zywnosci;

public class KalorieObliczenia {
    public static int CEL_KALORIE = 2000;
    public static int CEL_BIALKO = 150;
    public static int CEL_TLUSZCZ = 70;
    public static int CEL_WEGLE = 250;

    public static void ustawCel(int wiek, int waga, int wzrost, String cel) {
        int ppm = (int)(10 * waga + 6.25 * wzrost - 5 * wiek + 5);

        switch (cel) {
            case "Redukcja":
                CEL_KALORIE = ppm - 300;
                CEL_BIALKO = (int)(waga * 2.2);       // więcej białka
                CEL_TLUSZCZ = (int)(waga * 0.7);       // mniej tłuszczu
                break;

            case "Utrzymanie":
                CEL_KALORIE = ppm;
                CEL_BIALKO = (int)(waga * 2.0);
                CEL_TLUSZCZ = (int)(waga * 1.0);
                break;

            case "Masa":
                CEL_KALORIE = ppm + 300;
                CEL_BIALKO = (int)(waga * 2.0);
                CEL_TLUSZCZ = (int)(waga * 1.2);       // więcej tłuszczu
                break;
        }

        // Oblicz węgle jako resztę kalorii
        CEL_WEGLE = (CEL_KALORIE - (CEL_BIALKO * 4 + CEL_TLUSZCZ * 9)) / 4;
    }
}


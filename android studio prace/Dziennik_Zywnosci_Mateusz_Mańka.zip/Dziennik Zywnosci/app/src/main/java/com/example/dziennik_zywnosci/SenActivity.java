package com.example.dziennik_zywnosci;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SenActivity extends AppCompatActivity {

    private EditText etSen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sen);

        etSen = findViewById(R.id.etSen);
        Button btnZapiszSen = findViewById(R.id.btnZapiszSen);

        btnZapiszSen.setOnClickListener(v -> {
            String senStr = etSen.getText().toString().trim();
            if (!senStr.isEmpty()) {
                int senGodziny = Integer.parseInt(senStr);
                MagazynDanych.aktualnySen = senGodziny;
                Toast.makeText(this, "Zapisano: " + senGodziny + " godz.", Toast.LENGTH_SHORT).show();
                finish(); // wróć do MainActivity
            } else {
                Toast.makeText(this, "Podaj liczbę godzin snu", Toast.LENGTH_SHORT).show();
            }
        });
    }
}


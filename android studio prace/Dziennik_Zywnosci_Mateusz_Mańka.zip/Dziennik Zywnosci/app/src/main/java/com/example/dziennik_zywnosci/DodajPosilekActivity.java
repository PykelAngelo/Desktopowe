package com.example.dziennik_zywnosci;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class DodajPosilekActivity extends AppCompatActivity {

    private EditText etNazwa, etKalorie, etBialko, etTluszcz, etWegle;
    private Button btnZapisz;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_meal);

        etNazwa = findViewById(R.id.etMealName);
        etKalorie = findViewById(R.id.etCalories);
        etBialko = findViewById(R.id.etProtein);
        etTluszcz = findViewById(R.id.etFat);
        etWegle = findViewById(R.id.etCarbs);
        btnZapisz = findViewById(R.id.btnSaveMeal);

        btnZapisz.setOnClickListener(v -> {
            String nazwa = etNazwa.getText().toString().trim();
            int kal = Integer.parseInt(etKalorie.getText().toString());
            int bialko = Integer.parseInt(etBialko.getText().toString());
            int tluszcz = Integer.parseInt(etTluszcz.getText().toString());
            int wegle = Integer.parseInt(etWegle.getText().toString());

            Posilek p = new Posilek(nazwa, kal, bialko, tluszcz, wegle);
            MagazynDanych.listaPosilkow.add(p);

            Toast.makeText(this, "Dodano posiłek", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}

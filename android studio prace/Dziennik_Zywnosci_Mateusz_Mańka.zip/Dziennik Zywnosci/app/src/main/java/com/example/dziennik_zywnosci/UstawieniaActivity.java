package com.example.dziennik_zywnosci;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class UstawieniaActivity extends AppCompatActivity {

    private EditText etWiek, etWaga, etWzrost;
    private Spinner spinnerCel;
    private Button btnZapisz;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ustawienia);

        etWiek = findViewById(R.id.etWiek);
        etWaga = findViewById(R.id.etWaga);
        etWzrost = findViewById(R.id.etWzrost);
        spinnerCel = findViewById(R.id.spinnerCel);
        btnZapisz = findViewById(R.id.btnZapiszCel);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.cele_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCel.setAdapter(adapter);

        btnZapisz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int wiek = Integer.parseInt(etWiek.getText().toString());
                int waga = Integer.parseInt(etWaga.getText().toString());
                int wzrost = Integer.parseInt(etWzrost.getText().toString());
                String cel = spinnerCel.getSelectedItem().toString();

                KalorieObliczenia.ustawCel(wiek, waga, wzrost, cel);

                Toast.makeText(UstawieniaActivity.this, "Cele zaktualizowane!", Toast.LENGTH_SHORT).show();
                finish(); // wróć do MainActivity
            }
        });
    }
}
